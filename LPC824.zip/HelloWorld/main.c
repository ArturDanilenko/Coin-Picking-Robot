#include "lpc824.h"
#include "serial.h"
#include <stdlib.h>
#include <stdio.h>

void ConfigPins()
{
	GPIO_DIR0 |= BIT14; 
}

void delay(int len)
{
	while(len--);
}

void main(void)
{
	ConfigPins();	
	initUART(115200);
	enable_interrupts();
	
	printf("Hello, World!\r\n");
	
	while(1)	
	{
		GPIO_B14 = 1;
		delay(500000);
		GPIO_B14 = 0;
		delay(500000);
	}
}
