#include "lpc824.h"
#include "serial.h"
#include <stdio.h>
#include <stdlib.h>

void ConfigPins(void)
{
	GPIO_DIR0 |= BIT14; 
}

void delay(int len)
{
	while(len--);
}

/* Start ADC calibration */
void ADC_Calibration(void)
{
	unsigned int saved_ADC_CTRL;

	// Follow the instructions from the user manual (21.3.4 Hardware self-calibration)
	
	//To calibrate the ADC follow these steps:
	
	//1. Save the current contents of the ADC CTRL register if different from default.	
	saved_ADC_CTRL=ADC_CTRL;
	// 2. In a single write to the ADC CTRL register, do the following to start the
	//    calibration:
	//    � Set the calibration mode bit CALMODE.
	//    � Write a divider value to the CLKDIV bit field that divides the system
	//      clock to yield an ADC clock of about 500 kHz.
	//    � Clear the LPWR bit.
	ADC_CTRL = BIT30 | ((300/5)-1); // BIT30=CALMODE, BIT10=LPWRMODE, BIT7:0=CLKDIV
	// 3. Poll the CALMODE bit until it is cleared.
	while(ADC_CTRL&BIT30);
	// Before launching a new A/D conversion, restore the contents of the CTRL
	// register or use the default values.
	ADC_CTRL=saved_ADC_CTRL;
}


void InitADC(void)
{
	// Will use Pin 1 (TSSOP-20 package) or PIO_23 for ADC.
	// This corresponds to ADC Channel 3.  Also connect the
	// VREFN pin (pin 17 of TSSOP-20) to GND, and VREFP the
	// pin (pin 17 of TSSOP-20) to VDD (3.3V).
	
	SYSCON_PDRUNCFG &= ~BIT4; // Power up the ADC
	SYSCON_SYSAHBCLKCTRL |= BIT24;// Start the ADC Clocks
	ADC_Calibration();
	ADC_SEQA_CTRL &= ~BIT31; // Ensure SEQA_ENA is disabled before making changes	
	
	ADC_CTRL =1;// Set the ADC Clock divisor
	SWM_PINENABLE0 &=~BIT16; // Enable the ADC function on PIO_23	
	ADC_SEQA_CTRL |= BIT3; // Select Channel 3	
	ADC_SEQA_CTRL |= BIT31 + BIT18; // Set SEQA and Trigger polarity bits
}

int ReadADC(void)
{
	ADC_SEQA_CTRL |= BIT26; // Start a conversion:
	while( (ADC_SEQA_GDAT & BIT31)==0); // Wait for data valid
	return ( (ADC_SEQA_GDAT >> 4) & 0xfff);
}

void main(void)
{
	int j, v;
	
	ConfigPins();	
	initUART(115200);
	InitADC();
	enable_interrupts();
	printf("Start\r\n");
	fflush(stdout);
	while(1)	
	{
		GPIO_B14 = 1;
		delay(500000);		
		
		j=ReadADC();
		v=(j*33000)/0xfff;
		printf("ADC[3]=0x%04x, %d.%04dV\r", j, v/10000, v%10000);
		fflush(stdout);
		
		GPIO_B14 = 0;	
		delay(500000);	
	}
}
