#include "lpc824.h"
#include "serial.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

void ConfigPins()
{
	GPIO_DIR0 |= BIT14; 
}

void delay(int len)
{
	while(len--);
}

void main(void)
{
	int Counter=100, j;

	ConfigPins();
	initUART(115200);
	enable_interrupts();

	printf("Testing printf() from newlib_nano in LPC824\r\n");
	for(j=0; j<10; j++)	
	{
		printf("Counter: %d (0x%08x)\r\n", Counter, Counter);
		Counter++;
	}
	printf("Good PI: %f\r\n", 355.0/113.0);
	
	// After this we pretty much run out of memory.
	for(j=0; j<32; j++)
	{
		printf("sin(%f)=%f\r\n", j*0.1, sinf(j*0.1) );
	}
	
	while(1)
	{
		GPIO_B14 ^= 1;
		delay(500000);
		//GPIO_B14 = 0;
		//delay(500000);
	}
}
