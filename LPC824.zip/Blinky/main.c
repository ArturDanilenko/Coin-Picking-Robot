#include "lpc824.h"

void ConfigPins()
{
	GPIO_DIR0 |= BIT14; 
}

void delay(int len)
{
	while(len--);
}

void main(void)
{
	ConfigPins();
	
	// Test code: This routes main clock (divided by 100) to pin 1
	SYSCON_CLKOUTSEL = 3; // select main clock as clock out source
	SYSCON_CLKOUTDIV = 100; // divide down so easier to measure
	SYSCON_CLKOUTUEN = 1; // update clockout source
	SWM_PINASSIGN11 = (23 << 16); // route clock out on pin 1 (GPIO0_23)
	while(1)	
	{
		GPIO_B14 = 1;
		delay(1000000);
		GPIO_B14 = 0; 
		delay(1000000);
	}
}
