#include "lpc824.h"
#include "serial.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

void main(void)
{
	initUART(115200);
	enable_interrupts();

    GPIO_DIR0 &= ~(BIT1); // Configure PIO0_1 as input

	printf("Push button test for the LPC824.  Connect push button between PIO0_1 and GND.\r\n");

	while(1)
	{
		printf("PIO0_1 (pin 12)=%c\r", GPIO_B1?'1':'0');
		fflush(stdin);
	}
}
