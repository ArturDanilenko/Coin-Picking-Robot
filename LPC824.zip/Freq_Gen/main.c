// Freq_Gen.mk: this LPC824 project shows how to output a square wave
// at a desired frequency on one of the pins of the microcontroller.
// Actually two frequencies are generated, f at PIO_15 (pin 11) and 2f
// at PIO_14 (pin 20).  Pin PIO_14 is directly controlled by the timer.
// PIO_15 is changed using the interrupt service routine for the timer.

#include "lpc824.h"
#include "serial.h"

#define SYSTEM_CLK 30000000L
#define DEFAULT_F 15000L

// COnfigure the pins as outputs
void ConfigPins(void)
{
	GPIO_DIR0 |= BIT14; 
	GPIO_DIR0 |= BIT15; 
}

void InitTimer(void)
{
	SCTIMER_CTRL |= BIT2; // halt SCTimer

    // Assign a pin to the timer.
    // Assign GPIO_14 to SCT_OUT0_O
	SWM_PINASSIGN7 &= 0x00ffffff;
	SWM_PINASSIGN7 |= (14 << 24); 
	
	SYSCON_SYSAHBCLKCTRL |= BIT8; // Turn on SCTimer 
	SYSCON_PRESETCTRL |=  BIT8; // Clear the reset SCT control
	
	SCTIMER_CONFIG |= BIT0; // Unified 32 bit counter
	SCTIMER_MATCH0 = SYSTEM_CLK/(DEFAULT_F*2L); // Set delay period 
	SCTIMER_MATCHREL0 = SYSTEM_CLK/(DEFAULT_F*2L);
	SCTIMER_EV0_STATE = BIT0;  // Event 0 pushes us into state 0
	// Event 0 configuration:
	// Event occurs on match of MATCH0, new state is 1	
	SCTIMER_EV0_CTRL =  BIT12 + BIT14 + BIT15;
	// State 1 configuration
	SCTIMER_EV1_STATE = BIT1;  // Event 1 pushes us into state 1
	// Event 1 configuration
	// Event occurs on MATCH0, new state is 0
	SCTIMER_EV1_CTRL =  BIT12 + BIT14;
	// OUT0 is set by event 0
	SCTIMER_OUT0_SET = BIT0;
	// OUT1 is cleared by event 1
	SCTIMER_OUT0_CLR = BIT1;
	// Processing events 0 and 1
	SCTIMER_LIMIT_L = BIT0 + BIT1;
	// Remove halt on SCTimer
	SCTIMER_CTRL &= ~BIT2;		
		
	SCTIMER_EVEN = 0x01; //Interrupt on event 0
	NVIC_ISER0|=BIT9; // Enable SCT interrupts in NVIC
}

void Reload_SCTIMER (unsigned long Dly)
{
	SCTIMER_CTRL |= BIT2; // halt SCTimer
	SCTIMER_MATCH0 = Dly; // Set delay period 
	SCTIMER_MATCHREL0 = Dly;
	SCTIMER_COUNT = 0;
	SCTIMER_CTRL &= ~BIT2;	// Remove halt on SCTimer	
}

void delay(int len)
{
	while(len--);
}

void STC_IRQ_Handler(void)
{
	SCTIMER_EVFLAG = 0x01; // Clear interrupt flag
	GPIO_B15 = GPIO_B15?0:1;
}

int myAtoi(char *str)
{
    int i, res=0;
    for (i=0; str[i]!='\0'; ++i) res=res*10+(str[i]-'0');
    return res;
}

void main(void)
{
	int newF;
	char buff2[100];
	unsigned long reload;
	
	ConfigPins();	
	InitTimer();
	initUART(115200);
	enable_interrupts();
	eputs("Frequency generator using LPC824\r\n");
	while(1)	
	{
	    eputs("\r\nNew Frequency: ");
	    egets(buff2, 100-1);
	    newF=myAtoi(buff2);
	    if(newF>300000L)
	    {
	       eputs("Warning: High frequencies will cause the interrupt service routine for\r\n"
	             "the timer to take all available processor time.  Capping to 300000Hz.\r\n");
	       newF=300000L;
	    }
	    reload=SYSTEM_CLK/(newF*2L);
	    eputs("\r\nFrequency set to: ");
        PrintNumber(SYSTEM_CLK/(reload*2L), 10, 1);
	    Reload_SCTIMER(reload);
	}
}
